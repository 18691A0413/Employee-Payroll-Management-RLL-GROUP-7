export class Employee {
  id: number = 0;
  name: string = '';
  mail_id: string = '';
  role: string = '';
  category: string = '';
  gender: string = '';
}
