import { Component } from '@angular/core';

@Component({
  selector: 'home-image',
  templateUrl: './home-image.component.html',
  styleUrls: ['./home-image.component.css']
})
export class HomeImageComponent {

}
